#TP PCB
4 séances
1. Intro (slides?), Schéma, association empreintes
2. Routage
3. Écriture du driver
4. Soudure, test...
